#!/usr/bin/env python
"""Minimal setup.py which primarily reads everything from setup.cfg."""

import setuptools

if __name__ == "__main__":
    setuptools.setup()
