This code is the fruit of Kate Morley's labor, taken from here:

- http://code.iamkate.com/javascript/collapsible-lists/

which has been updated here:

- https://iamkate.com/code/tree-views/

and there is a strong desire for this folder to update accordingly, when
possible:

- https://github.com/svenevs/exhale/issues/180

She includes a generous CC0 1.0 license for all materials on her site:

- https://iamkate.com/code/
